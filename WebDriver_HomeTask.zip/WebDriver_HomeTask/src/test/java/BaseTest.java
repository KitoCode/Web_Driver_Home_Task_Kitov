import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import static io.github.bonigarcia.wdm.WebDriverManager.chromedriver;

public class BaseTest {
    private WebDriver driver;

    @BeforeTest
    public void profileSetUp() {
        chromedriver().setup();
    }

    @BeforeMethod
    public void testsSetUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.google.com.ua/?hl=ru");
    }

    public WebDriver getDriver() {
        return driver;
    }
    private static final String INPUTTEXT = "//input[@class='gLFyf gsfi']";
    private static final String GOTOIMAGETAB = "//a[@data-hveid='CAEQAw']";

    @Test
    public void searchForAnImage()
    {
        driver.findElement(By.xpath(INPUTTEXT)).sendKeys("Scott Scale 900 World Cup купить Украина");
        driver.findElement(By.xpath(INPUTTEXT)).sendKeys(Keys.ENTER);
        driver.findElement(By.xpath(GOTOIMAGETAB)).click();
        WebElement i = driver.findElement
                (By.xpath("//*[@id='islrg']/div[1]/div[2]/a[1]/div[1]/img"));
        Boolean p = (Boolean) ((JavascriptExecutor)driver) .executeScript("return arguments[0].complete " + "&& typeof arguments[0].naturalWidth != \"undefined\" " + "&& arguments[0].naturalWidth > 0", i);
        if (p) {
            System.out.println("Изображение отображается");
        } else {
            throw new NullPointerException("Изображение не отображается!!!");
        }
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }


}
